package main;

import java.sql.SQLException;
import java.util.List;
import java.util.Scanner;

/**
 *
 * @author omerbegovic
 */
public class Perzistencija {

    public static void main(String[] args) throws SQLException {

        doTheThing();

    }

    public static void doTheThing() throws SQLException {
        Scanner unos = new Scanner(System.in);
        System.out.println("Zdravo!\n Izaberite opciju?");
        System.out.println("(L)ista zaposlenih, (P)retrazi, (M)odifikuj, (I)zbrisi, (D)odaj novog radnika ili (N)apustanje aplikacije");
        String opcija = unos.nextLine();

        if (opcija.equalsIgnoreCase("l")) {
            System.out.println("Izabrali ste (L)istu zaposlenih");
            List<Podaci> podaci = Podaci.List();
            for (Podaci podaci1 : podaci) {
                System.out.println(podaci1);

            }
            doTheThing();
        } else if (opcija.equalsIgnoreCase("p")) {
            System.out.println("Izabrali ste (P)retrazivanje");
            System.out.println("Unesi ime koje te zanima: ");
            String name = unos.nextLine();
            List<Podaci> podaci = Podaci.Search(name);
            if (podaci.isEmpty()) {
                System.out.println("Ne postoji!");
                doTheThing();
            }
            for (Podaci podaci1 : podaci) {

                System.out.println(podaci1);

            }
            doTheThing();
        } else if (opcija.equalsIgnoreCase("m")) {
            System.out.println("Izabrali ste (M)odifikaciju");
            List<Podaci> podaci = Podaci.List();
            for (Podaci podaci1 : podaci) {
                System.out.println(podaci1);

            }
            Podaci pod = new Podaci();
            System.out.print("Unesi id zaposlenog koji zelis da izmenis: ");
            pod.setId(unos.nextInt());
            unos.nextLine();
            System.out.println("Sta zelis da izmenis?Unesi (vd) za visinu dohotka ili (a) za adresu");
            String choice = unos.nextLine();
            if (choice.equalsIgnoreCase("vd")) {
                System.out.println("Unesi novu visinu dohotka:");
                pod.setVisinaDohotka(unos.nextInt());
                pod.UpdateVisinaDohotka();
            } else if (choice.equalsIgnoreCase("a")) {
                System.out.println("Unesi novu adresu: ");
                pod.setAdresa(unos.nextLine());
                pod.UpdateAdresa();
            }
            doTheThing();
        } else if (opcija.equalsIgnoreCase("i")) {
            System.out.println("Izabrali ste (I)zbrisi");
            List<Podaci> podaci = Podaci.List();
            for (Podaci podaci1 : podaci) {
                System.out.println(podaci1);

            }
            Podaci pod = new Podaci();
            System.out.print("Unesi id zaposlenog kojeg zelis da izbrises: ");
            pod.setId(unos.nextInt());
            unos.nextLine();
            pod.Delete();
            doTheThing();
        } else if (opcija.equalsIgnoreCase("d")) {
            System.out.println("Izaberi (D)odaj novog zaposlenog");
            Podaci pod = new Podaci();
            System.out.println("Unesi ime: ");
            pod.setIme(unos.nextLine());
            System.out.println("Unesi broj godina: ");
            pod.setBrojGodina(unos.nextInt());
            System.out.println("Unesi adresu: ");
            pod.setAdresa(unos.next());
            System.out.println("Unesi visinu dohotka: ");
            pod.setVisinaDohotka(unos.nextInt());
            pod.Add();
            doTheThing();
        } else if (opcija.equalsIgnoreCase("n")) {
            System.out.println("Izabrali ste (N)apustanje aplikacije");
            System.exit(0);
        } else {
            System.out.println("Izabrali ste nepoznatu opciju. Molimo pokusajte ponovo.");
            doTheThing();
        }
    }
}